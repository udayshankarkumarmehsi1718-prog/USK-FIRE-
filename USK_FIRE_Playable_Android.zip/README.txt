USK FIRE - playable Android-friendly prototype
1. Open index.html in a modern Android browser.
2. For an app-like experience, use the browser menu -> Add to Home screen / Install app.
3. Lobby buttons, events, shop, missions, settings, music toggle, character selection and gameplay are functional.
4. Gameplay is an original 2D battle-arena prototype: movement, touch joystick, shooting, bots, loot, safe zone, win/lose and rewards.
5. This is not Free Fire and contains no Free Fire assets.
