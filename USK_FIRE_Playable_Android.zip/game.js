const $=id=>document.getElementById(id);
const state={level:+localStorage.level||1,coins:+localStorage.coins||1200,gems:+localStorage.gems||50,char:localStorage.char||"USK RANGER",music:localStorage.music!=="off",sensitivity:+localStorage.sensitivity||1,mission:+localStorage.mission||0};
function save(){for(const k of ["level","coins","gems","char","music","sensitivity","mission"])localStorage[k]=state[k]}
$("coins").textContent=state.coins;$("gems").textContent=state.gems;$("level").textContent=state.level;$("charName").textContent=state.char;$("charLevel").textContent=state.level;$("musicBtn").textContent=state.music?"🎵 ON":"🔇 OFF";

let audioCtx,osc;
function sound(freq=440,dur=.08,type="square"){if(!state.music)return;try{audioCtx??=new (window.AudioContext||window.webkitAudioContext)();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=.035;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+dur);o.stop(audioCtx.currentTime+dur)}catch(e){}}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
let load=0;const tips=["Preparing USK Island...","Loading original characters...","Loading weapons...","Starting battle systems...","Ready!"];
const li=setInterval(()=>{load+=4; $("loadbar").style.width=load+"%";$("loadpct").textContent=load+"%";$("tip").textContent=tips[Math.min(4,Math.floor(load/25))];if(load>=100){clearInterval(li);setTimeout(()=>show("lobby"),350)}},70);

function modal(type){
 const data={
 character:`<h2>👤 Characters</h2><div class="row"><div class="item"><b>USK RANGER</b><p>Balanced fighter • Speed 100</p><button onclick="chooseChar('USK RANGER')">EQUIP</button></div><div class="item"><b>FIRE NOVA</b><p>Fast fighter • Speed 110</p><button onclick="chooseChar('FIRE NOVA')">EQUIP</button></div><div class="item"><b>SHADOW X</b><p>Stealth fighter • Speed 105</p><button onclick="chooseChar('SHADOW X')">EQUIP</button></div></div>`,
 weapons:`<h2>🔫 Weapons</h2><div class="row"><div class="item"><b>USK AR-01</b><p>Damage 24 • Mag 30</p><button onclick="sound(220)">EQUIPPED</button></div><div class="item"><b>FURY SMG</b><p>Damage 18 • Mag 40</p><button onclick="sound(260)">EQUIP</button></div><div class="item"><b>LONGSHOT</b><p>Damage 60 • Mag 8</p><button onclick="sound(300)">EQUIP</button></div></div>`,
 inventory:`<h2>🎒 Inventory</h2><div class="row"><div class="item">🔫 USK AR-01<br>Ammo: 120</div><div class="item">🛡 Armor<br>Level 1</div><div class="item">❤️ Medkit<br>x3</div><div class="item">💣 Grenade<br>x2</div></div>`,
 missions:`<h2>🎯 Missions</h2><div class="item"><b>Play 1 match</b><p>Progress: ${Math.min(1,state.mission)}/1</p><button onclick="claimMission()">CLAIM 300 COINS</button></div><div class="item"><b>Get 3 kills</b><p>Complete this during a match.</p></div>`,
 events:`<h2>🔥 EVENTS</h2><div class="item"><b>USK FIRE WEEKEND</b><p>Play matches and earn bonus coins.</p><button onclick="sound(700,.15);alert('Event joined! Bonus rewards enabled for this session.')">JOIN EVENT</button></div><div class="item"><b>DAILY DROP</b><p>Free reward available.</p><button onclick="state.coins+=100;save();$("coins").textContent=state.coins;alert('100 coins added!')">CLAIM</button></div>`,
 shop:`<h2>🛒 SHOP</h2><div class="row"><div class="item"><b>Fire Outfit</b><p>500 coins</p><button onclick="buy(500,'Fire Outfit')">BUY</button></div><div class="item"><b>Neon Emote</b><p>300 coins</p><button onclick="buy(300,'Neon Emote')">BUY</button></div></div>`,
 friends:`<h2>👥 FRIENDS</h2><div class="item">USK_BUDDY • ONLINE</div><div class="item">FIRE_KING • OFFLINE</div>`,
 settings:`<h2>⚙️ SETTINGS</h2><div class="item">Graphics <button onclick="alert('Graphics: Adaptive / mobile optimized')">ADAPTIVE</button></div><div class="item">Sensitivity <button onclick="state.sensitivity=state.sensitivity>=2?.5:state.sensitivity+.5;save();alert('Sensitivity: '+state.sensitivity)">CHANGE</button></div><div class="item">Music <button onclick="toggleMusic()">TOGGLE</button></div>`
 };
 $("modalBody").innerHTML=data[type];$("modal").style.display="flex";sound(500);
}
document.querySelectorAll("[data-modal]").forEach(b=>b.onclick=()=>modal(b.dataset.modal));
$("closeModal").onclick=()=>$("modal").style.display="none";
function chooseChar(c){state.char=c;$("charName").textContent=c;save();$("modal").style.display="none";sound(650)}
function buy(n,name){if(state.coins>=n){state.coins-=n;save();$("coins").textContent=state.coins;alert(name+" purchased!")}else alert("Not enough coins.")}
function claimMission(){if(state.mission>=1){state.coins+=300;state.mission=0;save();$("coins").textContent=state.coins;alert("Reward claimed!")}else alert("Play a match first.")}
function toggleMusic(){state.music=!state.music;save();$("musicBtn").textContent=state.music?"🎵 ON":"🔇 OFF";sound(600)}
$("musicBtn").onclick=toggleMusic;

const canvas=$("gameCanvas"),ctx=canvas.getContext("2d");let W,H,player,bots,bullets,loot,keys={},gameTimer,zone,gameRunning=false,last=0,joy={x:0,y:0},running=false;
function resize(){W=canvas.width=innerWidth*devicePixelRatio;H=canvas.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);W=innerWidth;H=innerHeight}addEventListener("resize",resize);resize();
function startGame(){show("game");$("gameOver").style.display="none";player={x:W/2,y:H/2,r:18,hp:100,ammo:30,reserve:120,speed:2.8};bots=[];bullets=[];loot=[];for(let i=0;i<10;i++)bots.push({x:80+Math.random()*(W-160),y:90+Math.random()*(H-220),r:16,hp:60,cool:Math.random()*100});for(let i=0;i<18;i++)loot.push({x:40+Math.random()*(W-80),y:80+Math.random()*(H-170),type:Math.random()<.7?"ammo":"med",got:false});zone={x:W/2,y:H/2,r:Math.min(W,H)*.46,t:0};$("alive").textContent=11;$("kills").textContent=0;$("ammo").textContent="30 / 120";$("hpText").textContent=100;state.mission=1;save();gameRunning=true;last=performance.now();requestAnimationFrame(loop);sound(500,.2)}
$("startBtn").onclick=startGame;$("again").onclick=startGame;$("lobbyBtn").onclick=()=>{gameRunning=false;show("lobby");sound(420)};
function shoot(){if(!gameRunning||player.ammo<=0){if(player.ammo<=0)sound(90);return}player.ammo--;let a=Math.atan2((touchAim.y||player.y)-player.y,(touchAim.x||player.x)-player.x);bullets.push({x:player.x,y:player.y,vx:Math.cos(a)*8,vy:Math.sin(a)*8,life:80});$("ammo").textContent=player.ammo+" / "+player.reserve;sound(170,.05,"sawtooth")}
function reload(){if(player.ammo<30&&player.reserve>0){let n=Math.min(30-player.ammo,player.reserve);player.ammo+=n;player.reserve-=n;$("ammo").textContent=player.ammo+" / "+player.reserve;sound(300,.2)}}
function damage(n){player.hp=Math.max(0,player.hp-n);$("hpText").textContent=Math.round(player.hp);$("hpFill").style.width=player.hp+"%";if(player.hp<=0)endGame(false)}
function endGame(win){gameRunning=false;$("gameOver").style.display="flex";$("resultTitle").textContent=win?"USK WIN":"ELIMINATED";$("resultTitle").className=win?"win":"";$("resultText").textContent=win?`Victory! Kills: ${$("kills").textContent}. +500 coins.`:`You survived ${Math.floor((zone.t||0)/60)}s. Kills: ${$("kills").textContent}.`;if(win){state.coins+=500;state.level=Math.min(99,state.level+1);save();$("coins").textContent=state.coins;sound(880,.4,"triangle")}else sound(100,.4)}
let touchAim={x:W/2+100,y:H/2};let firing=false;
function loop(t){if(!gameRunning)return;let dt=Math.min(2,(t-last)/16.7);last=t;update(dt);draw();requestAnimationFrame(loop)}
function update(dt){let dx=(keys.d?1:0)-(keys.a?1:0)+joy.x,dy=(keys.s?1:0)-(keys.w?1:0)+joy.y;let len=Math.hypot(dx,dy)||1;let sp=player.speed*(running?1.65:1);player.x=Math.max(18,Math.min(W-18,player.x+dx/len*sp*dt));player.y=Math.max(75,Math.min(H-90,player.y+dy/len*sp*dt));
if(firing)shoot();
bullets.forEach(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt});bullets=bullets.filter(b=>b.life>0&&b.x>-20&&b.x<W+20&&b.y>-20&&b.y<H+20);
bots.forEach(b=>{let a=Math.atan2(player.y-b.y,player.x-b.x);let d=Math.hypot(player.x-b.x,player.y-b.y);if(d>150){b.x+=Math.cos(a)*.7*dt;b.y+=Math.sin(a)*.7*dt}else{b.cool-=dt;if(b.cool<=0&&d<380){damage(3+Math.random()*4);b.cool=45+Math.random()*45}}});
for(const b of bullets)for(const e of bots)if(e.hp>0&&Math.hypot(b.x-e.x,b.y-e.y)<e.r+5){e.hp-=25;b.life=0;if(e.hp<=0){let k=+$("kills").textContent+1;$("kills").textContent=k;sound(620,.08);if(k>=10)endGame(true)}}
for(const l of loot)if(!l.got&&Math.hypot(player.x-l.x,player.y-l.y)<28){l.got=true;if(l.type==="ammo"){player.reserve+=30}else player.hp=Math.min(100,player.hp+25);sound(520,.1)}
zone.t+=dt;if(zone.t>900){zone.r=Math.max(80,zone.r-.05*dt);$("zoneWarn").style.display="block"}if(Math.hypot(player.x-zone.x,player.y-zone.y)>zone.r){damage(.18*dt);$("zoneWarn").style.display="block"}else if(zone.t<=900)$("zoneWarn").style.display="none";
$("alive").textContent=Math.max(1,bots.filter(b=>b.hp>0).length+1)}
function draw(){ctx.clearRect(0,0,W,H);ctx.fillStyle="#28451e";ctx.fillRect(0,0,W,H);
ctx.strokeStyle="#365d29";for(let x=0;x<W;x+=60){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=60){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
ctx.fillStyle="#536c3d";for(let i=0;i<20;i++){let x=(i*97)%W,y=(i*151)%H;ctx.fillRect(x,y,40,24)}
ctx.save();ctx.globalAlpha=.45;ctx.fillStyle="#101010";ctx.beginPath();ctx.rect(0,0,W,H);ctx.arc(zone.x,zone.y,zone.r,0,Math.PI*2,true);ctx.fill("evenodd");ctx.restore();
ctx.strokeStyle="#ff9c22";ctx.lineWidth=3;ctx.beginPath();ctx.arc(zone.x,zone.y,zone.r,0,Math.PI*2);ctx.stroke();
for(const l of loot)if(!l.got){ctx.fillStyle=l.type==="ammo"?"#f5c542":"#44e87d";ctx.fillRect(l.x-7,l.y-7,14,14)}
for(const b of bots)if(b.hp>0){ctx.fillStyle="#d9362d";ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,7);ctx.fill();ctx.fillStyle="#111";ctx.fillRect(b.x-10,b.y-22,20,3);ctx.fillStyle="#42e879";ctx.fillRect(b.x-10,b.y-22,20*(b.hp/60),3)}
ctx.fillStyle="#4fb5ff";ctx.beginPath();ctx.arc(player.x,player.y,player.r,0,7);ctx.fill();ctx.strokeStyle="#fff";ctx.stroke();ctx.strokeStyle="#111";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(player.x,player.y);ctx.lineTo(player.x+Math.cos(Math.atan2(touchAim.y-player.y,touchAim.x-player.x))*28,player.y+Math.sin(Math.atan2(touchAim.y-player.y,touchAim.x-player.x))*28);ctx.stroke();for(const b of bullets){ctx.fillStyle="#ffd36a";ctx.beginPath();ctx.arc(b.x,b.y,4,0,7);ctx.fill()}}
document.addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==="r")reload();if(e.code==="Space")e.preventDefault()});document.addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
$("fireBtn").onpointerdown=()=>firing=true;$("fireBtn").onpointerup=()=>firing=false;$("reloadBtn").onclick=reload;$("runBtn").onpointerdown=()=>running=true;$("runBtn").onpointerup=()=>running=false;
let joyEl=$("joy"),knob=$("knob");function setJoy(e){let r=joyEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,d=Math.min(40,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);joy.x=Math.cos(a)*d/40;joy.y=Math.sin(a)*d/40;knob.style.transform=`translate(${joy.x*40}px,${joy.y*40}px)`}joyEl.onpointerdown=e=>{joyEl.setPointerCapture(e.pointerId);setJoy(e)};joyEl.onpointermove=e=>{if(e.buttons)setJoy(e)};joyEl.onpointerup=()=>{joy.x=joy.y=0;knob.style.transform="translate(0,0)"};
canvas.onpointermove=e=>{touchAim={x:e.clientX,y:e.clientY}};canvas.onpointerdown=e=>{touchAim={x:e.clientX,y:e.clientY};if(e.pointerType==="mouse")firing=true};canvas.onpointerup=()=>{firing=false};
